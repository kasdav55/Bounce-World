
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

const GRAVITY = 0.5;
const JUMP_STRENGTH = -10;
const PLATFORM_HEIGHT = 20;
const PLAYER_SIZE = 50;

let player, platforms, currentLevel;
const levels = [
    [
        { x: 100, y: 500, width: 200, height: PLATFORM_HEIGHT },
        { x: 400, y: 400, width: 200, height: PLATFORM_HEIGHT },
        { x: 250, y: 300, width: 200, height: PLATFORM_HEIGHT }
    ],
    [
        { x: 50, y: 450, width: 300, height: PLATFORM_HEIGHT },
        { x: 400, y: 350, width: 250, height: PLATFORM_HEIGHT },
        { x: 200, y: 200, width: 150, height: PLATFORM_HEIGHT }
    ],
    [
        { x: 100, y: 550, width: 200, height: PLATFORM_HEIGHT },
        { x: 500, y: 400, width: 150, height: PLATFORM_HEIGHT },
        { x: 300, y: 250, width: 300, height: PLATFORM_HEIGHT }
    ]
];

function resetPlayer() {
    player = {
        x: canvas.width / 2 - PLAYER_SIZE / 2,
        y: canvas.height - PLAYER_SIZE,
        width: PLAYER_SIZE,
        height: PLAYER_SIZE,
        velocityY: 0,
        isJumping: false
    };
}

function drawPlayer() {
    ctx.fillStyle = 'blue';
    ctx.fillRect(player.x, player.y, player.width, player.height);
}

function drawPlatforms() {
    ctx.fillStyle = 'red';
    platforms.forEach(platform => {
        ctx.fillRect(platform.x, platform.y, platform.width, platform.height);
    });
}

function updatePlayer() {
    if (player.isJumping) {
        player.velocityY = JUMP_STRENGTH;
        player.isJumping = false;
    }

    player.velocityY += GRAVITY;
    player.y += player.velocityY;

    // Check for collision with platforms
    platforms.forEach(platform => {
        if (player.x < platform.x + platform.width &&
            player.x + player.width > platform.x &&
            player.y + player.height > platform.y &&
            player.y + player.height < platform.y + platform.height &&
            player.velocityY > 0) {
            player.y = platform.y - player.height;
            player.velocityY = 0;
        }
    });

    // Prevent player from falling off the screen
    if (player.y > canvas.height - player.height) {
        player.y = canvas.height - player.height;
        player.velocityY = 0;
    } else if (player.y < 0) {
        showWinMessage();
    } else if (player.x < 0) {
        player.x = 0;
    } else if (player.x + player.width > canvas.width) {
        player.x = canvas.width - player.width;
    }
}

function showWinMessage() {
    document.getElementById('winnerText').style.display = 'block'; isWin = true;
    setTimeout(nextLevel, 2000);
}

let isWin = false;
function nextLevel() { isWin = false;
    document.getElementById('winnerText').style.display = 'none';
    currentLevel++;
    if (currentLevel >= levels.length) {
        currentLevel = 0;
    }
    platforms = levels[currentLevel];
    resetPlayer();
    gameLoop();
}

function gameLoop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawPlatforms();
    drawPlayer();
    updatePlayer();
    if (!isWin) { requestAnimationFrame(gameLoop); }
}

document.addEventListener('keydown', (event) => {
    if (event.code === 'Space') {
        player.isJumping = true;
    }
});

function startGame() {
    currentLevel = 0;
    platforms = levels[currentLevel];
    resetPlayer();
    gameLoop();
}

startGame();
